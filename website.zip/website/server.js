var express=require("express");
var fileuploader=require("express-fileupload");
var mysql2=require("mysql2");
var nodemailer=require("nodemailer");

var app=express();
app.listen(2005,function(){
    console.log("Server Started");
})
app.use(express.static("public"));
app.use(fileuploader());

app.get("/profile",function(req,resp){
    resp.sendFile(process.cwd()+"/public/profile-donor.html");
}) 
app.get("/index",function(req,resp){    
    resp.sendFile(process.cwd()+"/public/index2.html")
})
app.get("/admin",function(req,resp){    
  resp.sendFile(process.cwd()+"/public/dash-admin.html")
})
var dbConfig={
    host:"127.0.0.1",
    user:"root",
    password:"Harshita@241005",
    database:"profileform",
    dateStrings:true
  }
  
  var dbCon=mysql2.createConnection(dbConfig);
  dbCon.connect(function(jasoos){
      if(jasoos==null)
          console.log("Connected Successfulllyyy...");
          else
          console.log(jasoos);
  })

  let transport =nodemailer.createTransport(
    {
        host: "smtp.forwardemail.net",
        port: 465,
        secure: true,
        service :'gmail',
        auth : {
            user : 'harshitagarg2410@gmail.com',
            pass : 'nqgnzjdaepyeerzp'
        }
    }
)


app.use(express.urlencoded(true));
app.post("/profile-process-secure",function(req,resp){
    var fileName="nopic.jpg";
    if(req.files!=null)
     {
       //console.log(process.cwd());
        fileName=req.files.idpic.name;
       var path=process.cwd()+"/public/uploads/"+fileName;
       req.files.idpic.mv(path);
     }
      console.log(req.body);
      var email=req.body.txtEmail;
      var name=req.body.txtName;
      var mobile=req.body.txtNumber;
      var address=req.body.txtAdd;
      var city=req.body.city;
      var gender=req.body.Gender;
      var idproof=req.body.id;
      var ahours="";
      ahours=req.body.amtime+",";
      ahours=ahours+req.body.pmtime;


      dbCon.query("insert into donors(email,name,mobile,address,city,gender,proof,pic,ahours) values(?,?,?,?,?,?,?,?,?)",[email,name,mobile,address,city,gender,idproof,fileName,ahours],function(err){
        if(err==null)
        resp.send("Profile Sumbitted!!");
      else
        resp.send(err);
      })
})

//-----------------------------
app.get("/chk-email",function(req,resp){
  dbCon.query("select * from users where email=?",[req.query.kuchEmail],function(err,result){
    if(err==null)
    {
      if(result.length==1)
      
        resp.send("Already Taken!!");

      else
      resp.send("Available");

    }
    else
    resp.send(err);
  })
})


app.get("/chk-submit",function(req,resp){
 var email=req.query.kuchEmail;
  dbCon.query("insert into users(email,pwd,type,dos,status) values(?,?,?,current_date(),1)",[email,req.query.kuchPwd,req.query.KuchType],function(err){
    if(err==null)
    resp.send("Signup Successfullyy");
    else
    resp.send(err);
  })

  const mailOptions={
    from: 'harshitagarg2410@gmail.com',
    to:email,
    subject: 'BRIDGES OF JOY',
    text:'Welcome to our website,you are signed in successfullyyy ',
  };
  transport.sendMail(mailOptions,function(err,info){
    if(err){
      console.log(err)
    }
    else{
      console.log(info);
    }
  });
})


//------------------JSON------------------
app.get("/get-json-record",function(req,resp){
  dbCon.query("select * from donors where email=?",[req.query.kuchEmail],function(err,resultTableJSON){
    if(err==null)
    resp.send(resultTableJSON);
    else
    resp.send(err);
  })
})


//-----------update------

app.post("/update-process-secure",function(req,resp){
    var fileName;
    if(req.files!=null)
     {
       //console.log(process.cwd());
        fileName=req.files.idpic.name;
       var path=process.cwd()+"/public/uploads/"+fileName;
       req.files.idpic.mv(path);
     }
     else
   {
    fileName=req.body.hdn;
   }
      console.log(req.body);
      var email=req.body.txtEmail;
      var name=req.body.txtName;
      var mobile=req.body.txtNumber;
      var address=req.body.txtAdd;
      var city=req.body.city;
      var gender=req.body.Gender;
      var idproof=req.body.id;
      var ahours="";
      ahours=req.body.amtime+",";
      ahours=ahours+req.body.pmtime;


      dbCon.query("update donors set name=?,mobile=?,address=?,city=?,gender=?,proof=?,pic=?,ahours=? where email=?",[name,mobile,address,city,gender,idproof,fileName,ahours,email],function(err){
        if(err==null)
        resp.send("Profile Updated!!");
      else
        resp.send(err);
      })
})


app.get("/fgt",function(req,resp){
  dbCon.query("insert into medsavailable1 (email,med,expdate,packing,qty) values(?,?,?,?,?)",[req.query.Email,req.query.name,req.query.date,req.query.opt,req.query.kuchqty],function(err){
    if(err==null){
    resp.send("Medicines Availed");
    console.log("done");
    }
    else
    console.log(err);
  })
})





//----------login-------------------
app.get("/chk-details",function(req,resp){
  dbCon.query("select * from users where email=? and pwd=?",[req.query.kuchEmail,req.query.kuchPwd],function(err,result){
    if(err==null)
    {
      if(result.length==1){
      // alert("taken");
      //alert(JSON.stringify(respJSON));
        //resp.send(res ult);
        if(result[0].status==1)
        resp.send(result[0].type);
      
      else
      resp.send("Blocked");
      //alert("noo");

    }
    else
    resp.send("invalid User/Password");
    //alert(err);
  }
  else{
    resp.send(err);
    
  }
});
});


//-------------------------------------

app.get("/get-needy-record",function(req,resp){
  dbCon.query("select * from needyprof where email=?",[req.query.kuchEmail],function(err,resultTableJSON){
    if(err==null){
    resp.send(resultTableJSON);

    }
    else
    resp.send(err);
  })
})

//var av=respjson[0].av.split("-";)

app.use(express.urlencoded(true));
app.post("/submit-needy",function(req,resp){
    var fileName="nopic.jpg";
    if(req.files!=null)
     {
       //console.log(process.cwd());
        fileName=req.files.idpic.name;
       var path=process.cwd()+"/public/uploads/"+fileName;
       req.files.idpic.mv(path);
     }
      console.log(req.body);
      var email=req.body.Email;
      var name=req.body.Name;
      var mobile=req.body.Number;
      var address=req.body.Add;
      var city=req.body.txtcity;
      var dob=req.body.txtdob;
      var gender=req.body.gender;
      
      


      dbCon.query("insert into needyprof(email,name,mobile,address,city,dob,gender,id) values(?,?,?,?,?,?,?,?)",[email,name,mobile,address,city,dob,gender,fileName],function(err){
        if(err==null)
        resp.send("Profile Sumbitted!!");
      else
        resp.send(err);
      })
})


app.post("/update-needy",function(req,resp){
  var fileName;
  if(req.files!=null)
   {
     //console.log(process.cwd());
      fileName=req.files.idpic.name;
     var path=process.cwd()+"/public/uploads/"+fileName;
     req.files.idpic.mv(path);
   }
   else
 {
  fileName=req.body.hdn;
 }
    console.log(req.body);
    var email=req.body.Email;
      var name=req.body.Name;
      var mobile=req.body.Number;
      var address=req.body.Add;
      var city=req.body.txtcity;
      var dob=req.body.txtdob;
      var gender=req.body.gender;


    dbCon.query("update needyprof set name=?,mobile=?,address=?,city=?,dob=?,gender=?,id=? where email=?",[name,mobile,address,city,dob,gender,fileName,email],function(err){
      if(err==null)
      resp.send("Profile Updated!!");
    else
      resp.send(err);
    })
})
 
  
//-----------------------
/*app.get("/update-pass",function(req,resp){
  var email=req.query.txtemail;
  var oldpass=req.query.oldpass;
  var newpass=req.query.newpass;
  var confirm=req.query.conpass;
  dbCon.query("update users set pwd=? where email=?",[confirm,email],function(err){
    if(err==null)
    resp.send("Updated Successfully!!!")
    else
    resp.send(err);
  })
})*/

app.get("/change-needy-password", function (req, resp) {

  var email = req.query.chkemail;
  var oldpass = req.query.oldpass;
   var newpass = req.query.newpass;
  var conpass = req.query.conpass;
 // dbCon.query("select * from users where email = ? and pwd=?", [email, oldpass], function (err, result) {
      //if (err == null) 
      //{
         // if (result.length == 1) 
          //{
           //   dbCon.query("update users set pwd=? where email=?", [conpass, email], function (err) {
            //      if (err == null)
             //      {
              //        resp.send("update succesfully..");
              //    }
               //   else
                 // resp.send(err);
             // })
         // }
         // else {
           //   resp.send("incorrect emailid or password");

         // }
     // }
     // else
          //resp.send(err);
  //})
 if (oldpass==newpass) {
   resp.send("Old and new password are same");
 }
 if(newpass!=conpass) {
   resp.send("new and confirm password are different");
 }
 dbCon.query("update users set pwd=? where email=? and pwd=? ",[newpass,email,oldpass],function(err,result){
   if(err)
   // resp.send("updated successfully")

 {    resp.send(err)}


   if(result.affectedRows==0)
           
   { 
       resp.send("Incorrect old password or email");
  
 }
  else
  resp.send("password updated successfully");
  
 });
});



app.get("/change-pass", function (req, resp) {

  var email = req.query.chkemail;
  var oldpass = req.query.oldpass;
   var newpass = req.query.newpass;
  var conpass = req.query.conpass;
  if (oldpass==newpass) {
    resp.send("Old and new password are same");
  }
  if(newpass!=conpass) {
    resp.send("new and confirm password are different");
  }
  dbCon.query("update users set pwd=? where email=? and pwd=? ",[newpass,email,oldpass],function(err,result){
    if(err)
    // resp.send("updated successfully")
 
  {    resp.send(err)}
 
 
    if(result.affectedRows==0)
            
    { 
        resp.send("Incorrect old password or email");
   
  }
   else
   resp.send("password updated successfully");
   
  });
 });


 app.get("/get-needyangular-all-records",function(req,resp)
{
         //fixed                             //same seq. as in table
    dbCon.query("select * from needyprof",function(err,resultTableJSON)
    {
          if(err==null)
            resp.send(resultTableJSON);
              else
            resp.send(err);
    })
})

app.get("/get-donorangular-all-records",function(req,resp)
{
         //fixed                             //same seq. as in table
    dbCon.query("select * from donors",function(err,resultTableJSON)
    {
          if(err==null)
            resp.send(resultTableJSON);
              else
            resp.send(err);
    })
})

app.get("/get-usersangular-all-records",function(req,resp)
{
         //fixed                             //same seq. as in table
    dbCon.query("select * from users",function(err,resultTableJSON)
    {
          if(err==null)
            resp.send(resultTableJSON);
              else
            resp.send(err);
    })
})


app.get("/do-angular-delete",function(req,resp)
{
     //saving data in table
    var email=req.query.emailkuch;
    

         //fixed                             //same seq. as in table
    dbCon.query("delete from needyprof where email=?",[email],function(err,result)
    {
          if(err==null)
          {
            if(result.affectedRows==1)
              resp.send("Account Removed Successssfullllyyyyyyyyyyyyyyyyyyyyyyyy!!!!!!!!!");
            else
              resp.send("Inavlid Email id");
            }
              else
            resp.send(err);
    })
})

app.get("/do-donorangular-delete",function(req,resp)
{
     //saving data in table
    var email=req.query.emailkuch;
    

         //fixed                             //same seq. as in table
    dbCon.query("delete from donors  where email=?",[email],function(err,result)
    {
          if(err==null)
          {
            if(result.affectedRows==1)
              resp.send("Account Removed Successssfullllyyyyyyyyyyyyyyyyyyyyyyyy!!!!!!!!!");
            else
              resp.send("Inavlid Email id");
            }
              else
            resp.send(err);
    })
})



app.get("/do-usersangular-delete",function(req,resp)
{
     //saving data in table
    var email=req.query.kuchEmail;
    

         //fixed                             //same seq. as in table
    dbCon.query("delete from users  where email=?",[email],function(err,result)
    {
          if(err==null)
          {
            if(result.affectedRows==1)
              resp.send("Account Removed Successssfullllyyyyyyyyyyyyyyyyyyyyyyyy!!!!!!!!!");
            else
              resp.send("Inavlid Email id");
            }
              else
            resp.send(err);
    })
})


app.get("/get-block-users",function(req,resp){
  var email = req.query.kuchEmail;
  
dbCon.query("update users set status=0 where email=?", [email], function (err) {
  if (err == null)
      resp.send("User Blocked");
  else
      resp.send(err);

})
})


app.get("/unblock-user",function(req,resp){
  var email = req.query.kuchEmail;
  
dbCon.query("update users set status=1 where email=?", [email], function (err) {
  if (err == null)
      resp.send("User Unblocked");
  else
      resp.send(err);

})
})  



app.get("/get-meds-all-records",function(req,resp)
{
  // console.log(req.query.EmailKuch);
    
  
  
         //fixed                             //same seq. as in table
    dbCon.query("select * from medsavailable1 where email=?",[req.query.EmailKuch],function(err,resultTableJSON)
    {
      if(err==null){
        resp.send(resultTableJSON);
      }       
       else
        resp.send("NO such email found!!");
      })

    });



app.get("/get-cities",function(req,resp){
  dbCon.query("select distinct city from donors",function(err,resulttable){
      if(err==null)
      resp.send(resulttable);
      else
      resp.send(err);
  })
})        

app.get("/get-med",function(req,resp){
  dbCon.query("select distinct med from medsavailable1",function(err,resulttable){
      if(err==null)
      resp.send(resulttable);
      else
      resp.send(err);
  })
})


app.get("/fetch-donorsmeds",function(req,resp)
{
  console.log(req.query);
  var med=req.query.medKuch;
  var city=req.query.cityKuch;

  var query="select donors.email,donors.mobile,donors.gender,donors.ahours,donors.pic,donors.name,donors.address,donors.city,medsavailable1.med from donors  inner join medsavailable1 on donors.email= medsavailable1.email where medsavailable1.med=? and donors.city=?";
  

  dbCon.query(query,[med,city],function(err,resultTable)
  {
    console.log(resultTable+"      "+err);
  if(err==null)
    resp.send(resultTable);
  else
    resp.send(err);
  })
})



app.get("/do-medicines-delete",function(req,resp)
{
     //saving data in table
    var srno=req.query.emailkuch;
    

         //fixed                             //same seq. as in table
    dbCon.query("delete from medsavailable1 where srno=?",[srno],function(err,result)
    {
          if(err==null)
          {
            if(result.affectedRows==1)
              resp.send("Medicines Details Deleted!!");
            else
              resp.send("Inavlid Email id");
            }
              else
            resp.send(err);
    })
})